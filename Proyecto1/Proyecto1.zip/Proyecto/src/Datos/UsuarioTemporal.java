
package Datos;

public class UsuarioTemporal {

    private static String texto = "";
    
    public static String getTexto() {
        return texto;
    }

    public static void setTexto(String aTexto) {
        texto = aTexto;
    }
    
    
    
    
    
    
    
}
